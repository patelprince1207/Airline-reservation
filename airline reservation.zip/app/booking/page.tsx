"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { User, CheckCircle2 } from "lucide-react"
import Link from "next/link"
import { AuthHeader } from "@/components/auth-header"
import { PaymentForm } from "@/components/payment-form"

export default function BookingPage() {
  const [flight, setFlight] = useState<any>(null)
  const [step, setStep] = useState(1)
  const [passengerInfo, setPassengerInfo] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
  })

  useEffect(() => {
    const selectedFlight = localStorage.getItem("selectedFlight")
    if (selectedFlight) {
      setFlight(JSON.parse(selectedFlight))
    }
  }, [])

  const handlePassengerSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setStep(2)
  }

  const handlePaymentSuccess = () => {
    const booking = {
      id: "BK" + Date.now(),
      flight,
      passenger: passengerInfo,
      bookingDate: new Date().toISOString(),
      status: "Confirmed",
      totalPrice: flight.price,
    }

    const bookings = JSON.parse(localStorage.getItem("bookings") || "[]")
    bookings.push(booking)
    localStorage.setItem("bookings", JSON.stringify(bookings))

    setStep(3)
  }

  if (!flight) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <AuthHeader />

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className={`flex items-center gap-2 ${step >= 1 ? "text-sky-600" : "text-muted-foreground"}`}>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-sky-600 text-white" : "bg-muted"}`}
            >
              1
            </div>
            <span className="font-medium hidden sm:inline">Passenger Details</span>
            <span className="font-medium sm:hidden">Details</span>
          </div>
          <div className="w-12 h-px bg-border" />
          <div className={`flex items-center gap-2 ${step >= 2 ? "text-sky-600" : "text-muted-foreground"}`}>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-sky-600 text-white" : "bg-muted"}`}
            >
              2
            </div>
            <span className="font-medium">Payment</span>
          </div>
          <div className="w-12 h-px bg-border" />
          <div className={`flex items-center gap-2 ${step >= 3 ? "text-sky-600" : "text-muted-foreground"}`}>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-sky-600 text-white" : "bg-muted"}`}
            >
              3
            </div>
            <span className="font-medium hidden sm:inline">Confirmation</span>
            <span className="font-medium sm:hidden">Done</span>
          </div>
        </div>

        {/* Flight Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Flight Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-center">
              <div>
                <p className="font-bold text-lg">
                  {flight.airline} - {flight.flightNumber}
                </p>
                <p className="text-muted-foreground">
                  {flight.from} → {flight.to}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  {flight.departure} - {flight.arrival} | {flight.class}
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-sky-600">${flight.price}</p>
                <p className="text-sm text-muted-foreground">per person</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step 1: Passenger Details */}
        {step === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Passenger Details
              </CardTitle>
              <CardDescription>Enter the passenger information for this booking</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePassengerSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      value={passengerInfo.firstName}
                      onChange={(e) => setPassengerInfo({ ...passengerInfo, firstName: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      value={passengerInfo.lastName}
                      onChange={(e) => setPassengerInfo({ ...passengerInfo, lastName: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={passengerInfo.email}
                    onChange={(e) => setPassengerInfo({ ...passengerInfo, email: e.target.value })}
                    required
                  />
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={passengerInfo.phone}
                      onChange={(e) => setPassengerInfo({ ...passengerInfo, phone: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dob">Date of Birth</Label>
                    <Input
                      id="dob"
                      type="date"
                      value={passengerInfo.dateOfBirth}
                      onChange={(e) => setPassengerInfo({ ...passengerInfo, dateOfBirth: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-sky-600 hover:bg-sky-700">
                  Continue to Payment
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Payment */}
        {step === 2 && <PaymentForm amount={flight.price} onSuccess={handlePaymentSuccess} onBack={() => setStep(1)} />}

        {/* Step 3: Confirmation */}
        {step === 3 && (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center space-y-6 py-8">
                <div className="flex justify-center">
                  <div className="w-20 h-20 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                    <CheckCircle2 className="h-12 w-12 text-green-600" />
                  </div>
                </div>
                <div>
                  <h2 className="text-3xl font-bold mb-2">Booking Confirmed!</h2>
                  <p className="text-muted-foreground">
                    Your flight has been successfully booked. A confirmation email has been sent to{" "}
                    {passengerInfo.email}
                  </p>
                </div>
                <div className="bg-muted p-6 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-2">Booking Reference</p>
                  <p className="text-2xl font-bold">BK{Date.now()}</p>
                </div>
                <div className="flex gap-4">
                  <Button variant="outline" asChild className="flex-1 bg-transparent">
                    <Link href="/">Back to Home</Link>
                  </Button>
                  <Button asChild className="flex-1 bg-sky-600 hover:bg-sky-700">
                    <Link href="/my-bookings">View My Bookings</Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
