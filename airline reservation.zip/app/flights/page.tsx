"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plane, Clock, DollarSign, ArrowRight } from "lucide-react"
import { AuthHeader } from "@/components/auth-header"

interface Flight {
  id: string
  airline: string
  flightNumber: string
  from: string
  to: string
  departure: string
  arrival: string
  duration: string
  price: number
  availableSeats: number
  class: "Economy" | "Business" | "First"
}

export default function FlightsPage() {
  const [flights, setFlights] = useState<Flight[]>([])
  const [searchParams, setSearchParams] = useState<any>(null)

  useEffect(() => {
    const params = localStorage.getItem("flightSearch")
    if (params) {
      setSearchParams(JSON.parse(params))
    }

    const mockFlights: Flight[] = [
      {
        id: "1",
        airline: "SkyWings Air",
        flightNumber: "SW101",
        from: "New York",
        to: "London",
        departure: "10:00 AM",
        arrival: "10:00 PM",
        duration: "7h 0m",
        price: 599,
        availableSeats: 45,
        class: "Economy",
      },
      {
        id: "2",
        airline: "Global Express",
        flightNumber: "GE205",
        from: "New York",
        to: "London",
        departure: "2:30 PM",
        arrival: "2:30 AM",
        duration: "7h 0m",
        price: 549,
        availableSeats: 32,
        class: "Economy",
      },
      {
        id: "3",
        airline: "SkyWings Air",
        flightNumber: "SW102",
        from: "New York",
        to: "London",
        departure: "6:45 PM",
        arrival: "6:45 AM",
        duration: "7h 0m",
        price: 1299,
        availableSeats: 12,
        class: "Business",
      },
      {
        id: "4",
        airline: "Premium Airways",
        flightNumber: "PA450",
        from: "New York",
        to: "London",
        departure: "11:30 PM",
        arrival: "11:30 AM",
        duration: "7h 0m",
        price: 2599,
        availableSeats: 4,
        class: "First",
      },
    ]

    setFlights(mockFlights)
  }, [])

  const handleBookFlight = (flight: Flight) => {
    localStorage.setItem("selectedFlight", JSON.stringify(flight))
    window.location.href = "/booking"
  }

  return (
    <div className="min-h-screen bg-background">
      <AuthHeader />

      <div className="container mx-auto px-4 py-8">
        {/* Search Summary */}
        {searchParams && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Your Search</CardTitle>
              <CardDescription>
                {searchParams.from} → {searchParams.to} | {searchParams.departure} | {searchParams.passengers}{" "}
                passenger(s)
              </CardDescription>
            </CardHeader>
          </Card>
        )}

        {/* Flight Results */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Available Flights</h2>
          {flights.map((flight) => (
            <Card key={flight.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  {/* Flight Info */}
                  <div className="flex-1 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-lg">{flight.airline}</h3>
                        <p className="text-sm text-muted-foreground">{flight.flightNumber}</p>
                      </div>
                      <Badge variant={flight.class === "Economy" ? "secondary" : "default"}>{flight.class}</Badge>
                    </div>

                    <div className="flex items-center gap-8">
                      <div>
                        <p className="text-2xl font-bold">{flight.departure}</p>
                        <p className="text-sm text-muted-foreground">{flight.from}</p>
                      </div>
                      <div className="flex-1 flex flex-col items-center">
                        <Clock className="h-4 w-4 text-muted-foreground mb-1" />
                        <p className="text-sm text-muted-foreground">{flight.duration}</p>
                        <div className="w-full h-px bg-border my-2" />
                        <Plane className="h-5 w-5 text-sky-600" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{flight.arrival}</p>
                        <p className="text-sm text-muted-foreground">{flight.to}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{flight.availableSeats} seats available</span>
                    </div>
                  </div>

                  {/* Price & Booking */}
                  <div className="flex flex-col items-end gap-4 min-w-[200px]">
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-muted-foreground text-sm mb-1">
                        <DollarSign className="h-4 w-4" />
                        <span>Price per person</span>
                      </div>
                      <p className="text-3xl font-bold text-sky-600">${flight.price}</p>
                    </div>
                    <Button
                      onClick={() => handleBookFlight(flight)}
                      className="w-full bg-sky-600 hover:bg-sky-700"
                      size="lg"
                    >
                      Book Now
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
