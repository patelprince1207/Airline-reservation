"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plane, Calendar, MapPin, User } from "lucide-react"
import Link from "next/link"
import { AuthHeader } from "@/components/auth-header"

interface Booking {
  id: string
  flight: any
  passenger: any
  bookingDate: string
  status: string
  totalPrice: number
}

export default function MyBookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])

  useEffect(() => {
    const savedBookings = JSON.parse(localStorage.getItem("bookings") || "[]")
    setBookings(savedBookings)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <AuthHeader />

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">My Bookings</h1>

        {bookings.length === 0 ? (
          <Card>
            <CardContent className="py-16 text-center">
              <Plane className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h2 className="text-xl font-bold mb-2">No bookings yet</h2>
              <p className="text-muted-foreground mb-6">Start your journey by booking your first flight</p>
              <Button asChild className="bg-sky-600 hover:bg-sky-700">
                <Link href="/">Search Flights</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        Booking {booking.id}
                        <Badge variant="default" className="bg-green-600">
                          {booking.status}
                        </Badge>
                      </CardTitle>
                      <CardDescription>
                        <Calendar className="h-4 w-4 inline mr-1" />
                        Booked on {new Date(booking.bookingDate).toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-sky-600">${booking.totalPrice}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <h4 className="font-semibold flex items-center gap-2">
                        <Plane className="h-4 w-4" />
                        Flight Details
                      </h4>
                      <div className="space-y-1 text-sm">
                        <p>
                          <span className="text-muted-foreground">Airline:</span> {booking.flight.airline}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Flight:</span> {booking.flight.flightNumber}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Class:</span> {booking.flight.class}
                        </p>
                        <p className="flex items-center gap-2">
                          <MapPin className="h-3 w-3" />
                          {booking.flight.from} → {booking.flight.to}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Departure:</span> {booking.flight.departure}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Arrival:</span> {booking.flight.arrival}
                        </p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-semibold flex items-center gap-2">
                        <User className="h-4 w-4" />
                        Passenger Details
                      </h4>
                      <div className="space-y-1 text-sm">
                        <p>
                          <span className="text-muted-foreground">Name:</span> {booking.passenger.firstName}{" "}
                          {booking.passenger.lastName}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Email:</span> {booking.passenger.email}
                        </p>
                        <p>
                          <span className="text-muted-foreground">Phone:</span> {booking.passenger.phone}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
