"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Search, Calendar, Users, ArrowRight } from "lucide-react"
import { AuthHeader } from "@/components/auth-header"

export default function HomePage() {
  const [searchParams, setSearchParams] = useState({
    from: "",
    to: "",
    departure: "",
    returnDate: "",
    passengers: "1",
  })

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    localStorage.setItem("flightSearch", JSON.stringify(searchParams))
    window.location.href = "/flights"
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 to-background dark:from-sky-950/20">
      <AuthHeader />

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-16 pb-12">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-5xl font-bold mb-4 text-balance">Find Your Perfect Flight</h1>
          <p className="text-xl text-muted-foreground text-pretty">
            Book flights to destinations worldwide with ease. Best prices guaranteed.
          </p>
        </div>

        {/* Search Card */}
        <Card className="max-w-5xl mx-auto shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-sky-600" />
              Search Flights
            </CardTitle>
            <CardDescription>Enter your travel details to find available flights</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="from">From</Label>
                  <Input
                    id="from"
                    placeholder="Departure city"
                    value={searchParams.from}
                    onChange={(e) => setSearchParams({ ...searchParams, from: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="to">To</Label>
                  <Input
                    id="to"
                    placeholder="Destination city"
                    value={searchParams.to}
                    onChange={(e) => setSearchParams({ ...searchParams, to: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="departure" className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Departure Date
                  </Label>
                  <Input
                    id="departure"
                    type="date"
                    value={searchParams.departure}
                    onChange={(e) => setSearchParams({ ...searchParams, departure: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="return" className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    Return Date
                  </Label>
                  <Input
                    id="return"
                    type="date"
                    value={searchParams.returnDate}
                    onChange={(e) => setSearchParams({ ...searchParams, returnDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="passengers" className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Passengers
                  </Label>
                  <Input
                    id="passengers"
                    type="number"
                    min="1"
                    max="9"
                    value={searchParams.passengers}
                    onChange={(e) => setSearchParams({ ...searchParams, passengers: e.target.value })}
                    required
                  />
                </div>
              </div>

              <Button type="submit" size="lg" className="w-full bg-sky-600 hover:bg-sky-700">
                <Search className="h-5 w-5 mr-2" />
                Search Flights
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Best Price Guarantee</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                We ensure you get the best deals on flights worldwide with our price match guarantee.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">24/7 Customer Support</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Our dedicated support team is available around the clock to assist with your bookings.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Secure Booking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Your payment information is protected with industry-standard encryption technology.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
