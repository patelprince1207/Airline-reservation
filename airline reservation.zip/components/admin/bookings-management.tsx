"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Plane, User, Trash2 } from "lucide-react"

interface Booking {
  id: string
  flight: any
  passenger: any
  bookingDate: string
  status: string
  totalPrice: number
}

export function BookingsManagement() {
  const [bookings, setBookings] = useState<Booking[]>([])

  useEffect(() => {
    loadBookings()
  }, [])

  const loadBookings = () => {
    const savedBookings = JSON.parse(localStorage.getItem("bookings") || "[]")
    setBookings(savedBookings)
  }

  const handleDelete = (id: string) => {
    const updatedBookings = bookings.filter((b) => b.id !== id)
    localStorage.setItem("bookings", JSON.stringify(updatedBookings))
    setBookings(updatedBookings)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Bookings Management</CardTitle>
        <CardDescription>View and manage all flight bookings</CardDescription>
      </CardHeader>
      <CardContent>
        {bookings.length === 0 ? (
          <div className="text-center py-12">
            <Plane className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">No bookings yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-3">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold">{booking.id}</h4>
                        <Badge variant="default" className="bg-green-600">
                          {booking.status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3 inline mr-1" />
                          {new Date(booking.bookingDate).toLocaleDateString()}
                        </span>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4 text-sm">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 font-semibold">
                            <Plane className="h-4 w-4" />
                            Flight Details
                          </div>
                          <div className="space-y-1 text-muted-foreground">
                            <p>
                              {booking.flight.airline} - {booking.flight.flightNumber}
                            </p>
                            <p>
                              {booking.flight.from} → {booking.flight.to}
                            </p>
                            <p>
                              {booking.flight.departure} - {booking.flight.arrival}
                            </p>
                            <p>Class: {booking.flight.class}</p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center gap-2 font-semibold">
                            <User className="h-4 w-4" />
                            Passenger Details
                          </div>
                          <div className="space-y-1 text-muted-foreground">
                            <p>
                              {booking.passenger.firstName} {booking.passenger.lastName}
                            </p>
                            <p>{booking.passenger.email}</p>
                            <p>{booking.passenger.phone}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <p className="text-2xl font-bold text-sky-600">${booking.totalPrice}</p>
                      <Button variant="outline" size="icon" onClick={() => handleDelete(booking.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
