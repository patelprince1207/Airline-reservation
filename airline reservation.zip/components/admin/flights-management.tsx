"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Plane } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Flight {
  id: string
  airline: string
  flightNumber: string
  from: string
  to: string
  departure: string
  arrival: string
  duration: string
  price: number
  availableSeats: number
  class: "Economy" | "Business" | "First"
}

export function FlightsManagement() {
  const [flights, setFlights] = useState<Flight[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingFlight, setEditingFlight] = useState<Flight | null>(null)
  const [formData, setFormData] = useState({
    airline: "",
    flightNumber: "",
    from: "",
    to: "",
    departure: "",
    arrival: "",
    duration: "",
    price: "",
    availableSeats: "",
    class: "Economy" as "Economy" | "Business" | "First",
  })

  useEffect(() => {
    loadFlights()
  }, [])

  const loadFlights = () => {
    let savedFlights = JSON.parse(localStorage.getItem("adminFlights") || "[]")

    // Initialize with default flights if empty
    if (savedFlights.length === 0) {
      savedFlights = [
        {
          id: "1",
          airline: "SkyWings Air",
          flightNumber: "SW101",
          from: "New York",
          to: "London",
          departure: "10:00 AM",
          arrival: "10:00 PM",
          duration: "7h 0m",
          price: 599,
          availableSeats: 45,
          class: "Economy",
        },
        {
          id: "2",
          airline: "Global Express",
          flightNumber: "GE205",
          from: "New York",
          to: "London",
          departure: "2:30 PM",
          arrival: "2:30 AM",
          duration: "7h 0m",
          price: 549,
          availableSeats: 32,
          class: "Economy",
        },
        {
          id: "3",
          airline: "SkyWings Air",
          flightNumber: "SW102",
          from: "New York",
          to: "London",
          departure: "6:45 PM",
          arrival: "6:45 AM",
          duration: "7h 0m",
          price: 1299,
          availableSeats: 12,
          class: "Business",
        },
        {
          id: "4",
          airline: "Premium Airways",
          flightNumber: "PA450",
          from: "New York",
          to: "London",
          departure: "11:30 PM",
          arrival: "11:30 AM",
          duration: "7h 0m",
          price: 2599,
          availableSeats: 4,
          class: "First",
        },
      ]
      localStorage.setItem("adminFlights", JSON.stringify(savedFlights))
    }

    setFlights(savedFlights)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const flight: Flight = {
      id: editingFlight?.id || Date.now().toString(),
      airline: formData.airline,
      flightNumber: formData.flightNumber,
      from: formData.from,
      to: formData.to,
      departure: formData.departure,
      arrival: formData.arrival,
      duration: formData.duration,
      price: Number(formData.price),
      availableSeats: Number(formData.availableSeats),
      class: formData.class,
    }

    let updatedFlights
    if (editingFlight) {
      updatedFlights = flights.map((f) => (f.id === editingFlight.id ? flight : f))
    } else {
      updatedFlights = [...flights, flight]
    }

    localStorage.setItem("adminFlights", JSON.stringify(updatedFlights))
    setFlights(updatedFlights)
    resetForm()
    setIsAddDialogOpen(false)
  }

  const handleEdit = (flight: Flight) => {
    setEditingFlight(flight)
    setFormData({
      airline: flight.airline,
      flightNumber: flight.flightNumber,
      from: flight.from,
      to: flight.to,
      departure: flight.departure,
      arrival: flight.arrival,
      duration: flight.duration,
      price: flight.price.toString(),
      availableSeats: flight.availableSeats.toString(),
      class: flight.class,
    })
    setIsAddDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    const updatedFlights = flights.filter((f) => f.id !== id)
    localStorage.setItem("adminFlights", JSON.stringify(updatedFlights))
    setFlights(updatedFlights)
  }

  const resetForm = () => {
    setEditingFlight(null)
    setFormData({
      airline: "",
      flightNumber: "",
      from: "",
      to: "",
      departure: "",
      arrival: "",
      duration: "",
      price: "",
      availableSeats: "",
      class: "Economy",
    })
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Flights Management</CardTitle>
            <CardDescription>Add, edit, or remove flights from the system</CardDescription>
          </div>
          <Dialog
            open={isAddDialogOpen}
            onOpenChange={(open) => {
              setIsAddDialogOpen(open)
              if (!open) resetForm()
            }}
          >
            <DialogTrigger asChild>
              <Button className="bg-sky-600 hover:bg-sky-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Flight
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingFlight ? "Edit Flight" : "Add New Flight"}</DialogTitle>
                <DialogDescription>
                  {editingFlight ? "Update the flight details below" : "Enter the details for the new flight"}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="airline">Airline</Label>
                    <Input
                      id="airline"
                      value={formData.airline}
                      onChange={(e) => setFormData({ ...formData, airline: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="flightNumber">Flight Number</Label>
                    <Input
                      id="flightNumber"
                      value={formData.flightNumber}
                      onChange={(e) => setFormData({ ...formData, flightNumber: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="from">From</Label>
                    <Input
                      id="from"
                      value={formData.from}
                      onChange={(e) => setFormData({ ...formData, from: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="to">To</Label>
                    <Input
                      id="to"
                      value={formData.to}
                      onChange={(e) => setFormData({ ...formData, to: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="departure">Departure</Label>
                    <Input
                      id="departure"
                      placeholder="10:00 AM"
                      value={formData.departure}
                      onChange={(e) => setFormData({ ...formData, departure: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="arrival">Arrival</Label>
                    <Input
                      id="arrival"
                      placeholder="10:00 PM"
                      value={formData.arrival}
                      onChange={(e) => setFormData({ ...formData, arrival: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration</Label>
                    <Input
                      id="duration"
                      placeholder="7h 0m"
                      value={formData.duration}
                      onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Price ($)</Label>
                    <Input
                      id="price"
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seats">Available Seats</Label>
                    <Input
                      id="seats"
                      type="number"
                      value={formData.availableSeats}
                      onChange={(e) => setFormData({ ...formData, availableSeats: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="class">Class</Label>
                    <Select
                      value={formData.class}
                      onValueChange={(value: any) => setFormData({ ...formData, class: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Economy">Economy</SelectItem>
                        <SelectItem value="Business">Business</SelectItem>
                        <SelectItem value="First">First</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-sky-600 hover:bg-sky-700">
                  {editingFlight ? "Update Flight" : "Add Flight"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {flights.map((flight) => (
            <Card key={flight.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-2">
                      <Plane className="h-5 w-5 text-sky-600" />
                      <div>
                        <h4 className="font-bold">
                          {flight.airline} - {flight.flightNumber}
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {flight.from} → {flight.to}
                        </p>
                      </div>
                      <Badge variant={flight.class === "Economy" ? "secondary" : "default"}>{flight.class}</Badge>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-muted-foreground">Departure:</span> {flight.departure}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Arrival:</span> {flight.arrival}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Duration:</span> {flight.duration}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Seats:</span> {flight.availableSeats}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right mr-4">
                      <p className="text-xl font-bold text-sky-600">${flight.price}</p>
                    </div>
                    <Button variant="outline" size="icon" onClick={() => handleEdit(flight)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => handleDelete(flight.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
