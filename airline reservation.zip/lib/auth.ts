export interface User {
  id: string
  firstName: string
  lastName: string
  email: string
  password: string
  role: "user" | "admin"
  createdAt: string
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null
  const user = localStorage.getItem("currentUser")
  return user ? JSON.parse(user) : null
}

export function logout() {
  if (typeof window !== "undefined") {
    localStorage.removeItem("currentUser")
    window.location.href = "/"
  }
}

export function isAuthenticated(): boolean {
  return getCurrentUser() !== null
}

export function isAdmin(): boolean {
  const user = getCurrentUser()
  return user?.role === "admin"
}
